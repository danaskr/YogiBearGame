package game;

import java.awt.Image;

/**
 *
 * @author saker
 */
public class Walkable extends Sprite{
    
    public Walkable(int x, int y, int width, int height) {
        super(x, y, width, height,"src/images/sqr.png");
    } 

}
