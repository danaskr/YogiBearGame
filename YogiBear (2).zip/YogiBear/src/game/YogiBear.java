package game;

import java.io.IOException;

/**
 *
 * @author saker
 */
public class YogiBear {
   
    public static void main(String []args) throws IOException{
        //System.out.println("Working Directory: " + System.getProperty("user.dir"));
         MainMenuGUI MM = new MainMenuGUI();
    }

}
